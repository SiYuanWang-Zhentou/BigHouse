package com.zhentou.mybatis.controller;


import com.zhentou.mybatis.mapper.PersonalAccMapper;
import com.zhentou.mybatis.mapper.SystemMapper;
import com.zhentou.mybatis.pojo.*;
import com.zhentou.mybatis.pojo.System;
import com.zhentou.mybatis.utils.SqlSessionUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

@WebServlet("/personalServlet")
public class PersonalServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        super.init();
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        if (action.equals("createPersonal")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
            //个人查询取PERACCNUM
            String sname ="PERACCNUM";
            System seq1 = mapper.findSeq(sname);
            int i =seq1.getSeq();
            String seq = String.format("%012d", i );
            req.setAttribute("systemList", seq);
            req.getRequestDispatcher("/createPersonal.jsp").forward(req, resp);
        } else if (action.equals("createPersonalInfo")) {
            PersonalAcc personalAcc = getSingleRequest(req, PersonalAcc.class);
            double base = personalAcc.getBasenumber();//缴存基数
            double unit = personalAcc.getUnitprop();//单位比例
            double person = personalAcc.getIndiprop();//个人比例
            double unitMonpaysum = (base * unit);  //单位月应缴额：等于【缴存基数 * 单位比例】
            double perMonpaysum = (base * person); //个人月应缴额：等于【缴存基数 * 个人比例】
            personalAcc.setUnitmonpaysum(unitMonpaysum);
            personalAcc.setPermonpaysum(perMonpaysum);
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            SystemMapper mapper1 = sqlSession.getMapper(SystemMapper.class);
            int insertResult = mapper.insertSelective(new PersonalAcc(
                    personalAcc.getAccnum(),
                    personalAcc.getAccname(),
                    personalAcc.getIdcard(),
                    null,
//                    personalAcc.getUnitaccnum(),
                    personalAcc.getOpendate(),
                    personalAcc.getBalance(),
                    personalAcc.getPeraccstate(),
                    personalAcc.getBasenumber(),
                    personalAcc.getUnitprop(),
                    personalAcc.getIndiprop(),
                    personalAcc.getLastpaydate(),
                    personalAcc.getUnitmonpaysum(),
                    personalAcc.getPermonpaysum(),
                    personalAcc.getYpayamt(),
                    personalAcc.getYdrawamt(),
                    personalAcc.getYinterestbal(),
                    personalAcc.getInstcode(),
                    personalAcc.getOp(),
                    personalAcc.getRemark()
            ));
            if (insertResult == 0){
                req.getRequestDispatcher("/homeFailture.jsp").forward(req, resp);
            }else {
                System seq1 = mapper1.findSeq("PERACCNUM");
                int i =seq1.getSeq();
                System system = new System();
                system.setSeq(++i);
                SystemExample updateEx = new SystemExample();
                updateEx.createCriteria().andSeqnameEqualTo("PERACCNUM");
                mapper1.updateByExampleSelective(system,updateEx);

                List<PersonalAcc> personalAccList = mapper.selectByExample(null);
                req.setAttribute("personalList",personalAccList);
                req.getRequestDispatcher("/personalinfo.jsp").forward(req, resp);
            }
        }else if (action.equals("selectPerson")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            List<PersonalAcc> personalAccList = mapper.selectByExample(null);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/personalinfo.jsp").forward(req,resp);
        }else if (action.equals("deletePerson")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            String accnum = req.getParameter("accnum");
            int i = mapper.deleteByPrimaryKey(accnum);
            if(i == 0){
                req.getRequestDispatcher("/homeFailture.jsp").forward(req,resp);
            }else {
                List<PersonalAcc> personalAccList = mapper.selectByExample(null);
                req.setAttribute("personalList",personalAccList);
                req.getRequestDispatcher("/personalinfo.jsp").forward(req,resp);
            }
        }else if (action.equals("selectPersonByID")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            String accnum = req.getParameter("accnum");
            PersonalAcc personalAcc = mapper.selectByPrimaryKey(accnum);
            List<PersonalAcc> personalAccList = Collections.singletonList(personalAcc);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/personalinfoDetail.jsp").forward(req,resp);
        }else if (action.equals("updatePersonal")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            String accnum = req.getParameter("accnum");
            PersonalAcc personalAcc = mapper.selectByPrimaryKey(accnum);
            List<PersonalAcc> personalAccList = Collections.singletonList(personalAcc);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/updatePersonal.jsp").forward(req,resp);
        }else if (action.equals("updatePersonalByIDInfo")){
            PersonalAcc personalAcc = getSingleRequest(req, PersonalAcc.class);
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            int i = mapper.updateByPrimaryKeySelective(personalAcc);
            //修改后查询
            List<PersonalAcc> personalAccList = mapper.selectByExample(null);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/personalinfo.jsp").forward(req,resp);
        }else if (action.equals("SecondUpdatePersonal")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            List<PersonalAcc> personalAccList = mapper.selectByExample(null);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/personalinfoUpdate.jsp").forward(req,resp);
        }else if (action.equals("destroyPersonal")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            List<PersonalAcc> personalAccList = mapper.selectByExample(null);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/personalinfoDestory.jsp").forward(req,resp);
        }else if (action.equals("destroyPersonalInfo")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            String accnum = req.getParameter("accnum");
            PersonalAcc personalAcc = new PersonalAcc();
            personalAcc.setAccnum(accnum);
            personalAcc.setPeraccstate("9");
            personalAcc.setRemark("已销户");
            mapper.updateByPrimaryKeySelective(personalAcc);

            List<PersonalAcc> personalAccList = mapper.selectByExample(null);
            req.setAttribute("personalList",personalAccList);
            req.getRequestDispatcher("/personalinfoDestory.jsp").forward(req,resp);
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    public void destroy() {
        super.destroy();
    }

    //反射实体类赋值
    public static <T> T getSingleRequest(HttpServletRequest request, Class<T> obj) {
        //创建实例
        T instance = null;
        try {
            Field[] fields = obj.getDeclaredFields();
            instance = obj.newInstance();
            for (int i = 0; i < fields.length; i++) {
                String name = fields[i].getName();
                if (name.equals("serialVersionUID")) {
                    continue;
                }
                Class<?> type = obj.getDeclaredField(name).getType();

                String replace = name.substring(0, 1).toUpperCase()
                        + name.substring(1);
                Method setMethod = obj.getMethod("set" + replace, type);
                String str = request.getParameter(replace);
                if (str == null || "".equals(str)) {
                    String small = name.substring(0, 1).toLowerCase()
                            + name.substring(1);
                    str = request.getParameter(small);
                }
                if (str != null && !"".equals(str)) {
                    // ---判断读取数据的类型
                    if (type.isAssignableFrom(String.class)) {
                        setMethod.invoke(instance, str);
                    } else if (type.isAssignableFrom(BigDecimal.class)
                            || type.isAssignableFrom(BigDecimal.class)) {
                        setMethod.invoke(instance, str);
                    } else if (type.isAssignableFrom(int.class)
                            || type.isAssignableFrom(Integer.class)) {
                        setMethod.invoke(instance, Integer.parseInt(str));
                    } else if (type.isAssignableFrom(Double.class)
                            || type.isAssignableFrom(double.class)) {
                        setMethod.invoke(instance, Double.parseDouble(str));
                    } else if (type.isAssignableFrom(Boolean.class)
                            || type.isAssignableFrom(boolean.class)) {
                        setMethod.invoke(instance, Boolean.parseBoolean(str));
                    } else if (type.isAssignableFrom(Date.class)) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        setMethod.invoke(instance, dateFormat.parse(str));
                    } else if (type.isAssignableFrom(Timestamp.class)) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        setMethod.invoke(instance, new Timestamp(dateFormat.parse(str).getTime()));
                    }
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return instance;
    }
}
