package com.zhentou.mybatis.mapper;

import com.zhentou.mybatis.pojo.UnityAcc;
import com.zhentou.mybatis.pojo.UnityAccExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UnityAccMapper {
    /**
     * 根据条件查询总数
     */
    int countByExample(UnityAccExample example);

    /**
     * 根据条件删除
     */
    int deleteByExample(UnityAccExample example);

    /**
     * 根据主键删除
     */
    int deleteByPrimaryKey(String unitaccnum);

    /**
     * 插入数据
     */
    int insert(UnityAcc record);

    /**
     * 选择性插入数据
     */
    int insertSelective(UnityAcc record);

    /**
     * 根据条件查询
     */
    List<UnityAcc> selectByExample(UnityAccExample example);

    /**
     * 根据主键查询总数
     */
    UnityAcc selectByPrimaryKey(String unitaccnum);

    /**
     * 根据条件选择性修改
     */
    int updateByExampleSelective(@Param("record") UnityAcc record, @Param("example") UnityAccExample example);

    /**
     * 根据条件修改
     */
    int updateByExample(@Param("record") UnityAcc record, @Param("example") UnityAccExample example);

    /**
     * 根据主键选择性修改
     */
    int updateByPrimaryKeySelective(UnityAcc record);

    /**
     * 根据主键修改
     */
    int updateByPrimaryKey(UnityAcc record);
}