package com.zhentou.mybatis.mapper;

import com.zhentou.mybatis.pojo.PersonalAcc;
import com.zhentou.mybatis.pojo.PersonalAccExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface PersonalAccMapper {
    /**
     * 根据条件查询总数
     */
    int countByExample(PersonalAccExample example);

    /**
     * 根据条件删除
     */
    int deleteByExample(PersonalAccExample example);


    /**
     * 根据主键选择性删除
     */
    int deleteByPrimaryKey(String accnum);


    /**
     * 插入数据
     */
    int insert(PersonalAcc record);


    /**
     * 选择性插入数据
     */
    int insertSelective(PersonalAcc record);


    /**
     * 根据条件查询,返回集合
     */
    List<PersonalAcc> selectByExample(PersonalAccExample example);


    /**
     * 根据主键查询,返回集合
     */
    PersonalAcc selectByPrimaryKey(String accnum);

    /**
     * 根据条件选择性修改数据
     */
    int updateByExampleSelective(@Param("record") PersonalAcc record, @Param("example") PersonalAccExample example);


    /**
     * 根据条件修改数据
     */
    int updateByExample(@Param("record") PersonalAcc record, @Param("example") PersonalAccExample example);

    /**
     * 根据主键选择性修改数据
     */
    int updateByPrimaryKeySelective(PersonalAcc record);

    /**
     * 根据主键修改数据
     */
    int updateByPrimaryKey(PersonalAcc record);

    /**
     * 查询全部余额并求和
     * @return
     */
    PersonalAcc selectBalance();

    /**
     * 查询全部缴存基数
     * @return
     */
    PersonalAcc selectBasenumber();

    /**
     * 查询单位月应缴额之和
     */
    PersonalAcc selectUnitmonpaysum();

    /**
     * 查询个人月应缴额之和
     */
    PersonalAcc selectPermonpaysum();
}