package com.zhentou.mybatis.controller;

import com.zhentou.mybatis.mapper.OperatorMapper;
import com.zhentou.mybatis.mapper.SystemMapper;
import com.zhentou.mybatis.pojo.Operator;
import com.zhentou.mybatis.pojo.OperatorExample;
import com.zhentou.mybatis.pojo.System;
import com.zhentou.mybatis.pojo.SystemExample;
import com.zhentou.mybatis.utils.SqlSessionUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        //resp指的是响应
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        if (action.equals("login")) {
            String username = req.getParameter("username");
            String password = req.getParameter("password");
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            OperatorMapper mapper = sqlSession.getMapper(OperatorMapper.class);

            OperatorExample operatorExample = new OperatorExample();
            operatorExample.createCriteria().andOpNameEqualTo(username).andOpPasswordEqualTo(password).andOpStatusEqualTo("0").andOpNumIsNotNull();
            List<Operator> operators = mapper.selectByExample(operatorExample);

            if (operators == null || operators.size() == 0){
                req.getRequestDispatcher("/loginfail.jsp").forward(req,resp);
            }else{
                Operator op = new Operator();
                op.setOpStatus("1");
                OperatorExample updateExample = new OperatorExample();
                updateExample.createCriteria().andOpNumEqualTo(1);
                mapper.updateByExampleSelective(op, updateExample);
                req.setAttribute("OpName", username);
                req.getRequestDispatcher("/home.jsp").forward(req, resp);
            }
        }else if (action.equals("findAllSystem")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
            List<System> systemList = mapper.selectByExample(null);
            req.setAttribute("systemList", systemList);
            req.getRequestDispatcher("/systeminfo.jsp").forward(req, resp);

            //添加
        }else if (action.equals("insertSystemParemeter")) {
            req.getRequestDispatcher("/insertSysteminfo.jsp").forward(req, resp);
        }else if (action.equals("insertSystemInfo")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
            String seqname = req.getParameter("seqname");
            int seq = Integer.parseInt(req.getParameter("seq"));
            int maxseq = Integer.parseInt(req.getParameter("maxseq"));
            String descScript = req.getParameter("descScript");

            mapper.insertSelective(new System(seqname,seq,maxseq,descScript,null));
            List<System> systemList = mapper.selectByExample(null);
            req.setAttribute("systemList", systemList);
            req.getRequestDispatcher("/systeminfo.jsp").forward(req, resp);

            //删除
        }else if (action.equals("deleteSystemParemeter")) {
            String seqname = req.getParameter("seqname");
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);

            SystemExample deleteExample = new SystemExample();
            deleteExample.createCriteria().andSeqnameEqualTo(seqname);
            mapper.deleteByExample(deleteExample);

            List<System> systemList = mapper.selectByExample(null);
            req.setAttribute("systemList", systemList);
            req.getRequestDispatcher("/systeminfo.jsp").forward(req, resp);
        }else if (action.equals("updateSystemParemeter")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
            String oldname = req.getParameter("seqname");
            req.getSession().setAttribute("oldname",oldname);

            SystemExample selectOneEx = new SystemExample();
            selectOneEx.createCriteria().andSeqnameEqualTo(oldname);
            List<System> systemList = mapper.selectByExample(selectOneEx);
            req.setAttribute("systemList", systemList);
            req.getRequestDispatcher("/updateSysteminfo.jsp").forward(req, resp);
        }else if (action.equals("updateSystemInfo")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
            String oldname = req.getParameter("oldname");

            System system = new System();
            system.setSeqname(req.getParameter("seqname"));
            system.setSeq(Integer.valueOf(req.getParameter("seq")));
            system.setMaxseq(Integer.valueOf(req.getParameter("maxseq")));
            system.setDescScript(req.getParameter("descScript"));

            SystemExample updateExample = new SystemExample();
            updateExample.createCriteria().andSeqnameEqualTo(oldname);
            mapper.updateByExampleSelective(system,updateExample);

            List<System> systemList = mapper.selectByExample(null);
            req.setAttribute("systemList", systemList);
            req.getRequestDispatcher("/systeminfo.jsp").forward(req, resp);
        }else if (action.equals("exit")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            OperatorMapper mapper = sqlSession.getMapper(OperatorMapper.class);
            mapper.updateByPrimaryKeySelective(new Operator(1,null,null,"0"));
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    public void destroy() {
        super.destroy();
    }
}
