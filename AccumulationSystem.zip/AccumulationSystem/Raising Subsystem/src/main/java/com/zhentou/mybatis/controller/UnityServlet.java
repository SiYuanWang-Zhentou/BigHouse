package com.zhentou.mybatis.controller;

import com.zhentou.mybatis.mapper.PersonalAccMapper;
import com.zhentou.mybatis.mapper.SystemMapper;
import com.zhentou.mybatis.mapper.UnityAccMapper;
import com.zhentou.mybatis.pojo.*;
import com.zhentou.mybatis.pojo.System;
import com.zhentou.mybatis.utils.SqlSessionUtils;
import org.apache.ibatis.session.SqlSession;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;

@WebServlet("/unityServlet")
public class UnityServlet extends HttpServlet {
    @Override
    public void init() throws ServletException {
        super.init();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");

        String action = req.getParameter("action");
        if (action.equals("createUnity")) {
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
            //单位查询取UNITACCNUM
            String sname ="UNITACCNUM";
            System seq1 = mapper.findSeq(sname);
            int i =seq1.getSeq();
            String seq = String.format("%012d", i );
            req.setAttribute("systemList", seq);
            req.getRequestDispatcher("/createUnity.jsp").forward(req, resp);
        }else if (action.equals("createUnityInfo")){
            UnityAcc unityAcc = getSingleRequest(req,UnityAcc.class);
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
            PersonalAccExample personalAccExample = new PersonalAccExample();

            //单位人数：等于单位下所有非销户个人的人数，开户时默认为0
            personalAccExample.createCriteria().andAccnameIsNotNull().andPeraccstateEqualTo("0");
            int personCount = mapper.countByExample(personalAccExample);
            unityAcc.setPersnum(personCount);               //单位人数
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = mapper.selectBalance();
            unityAcc.setBalance(personalAcc.getBalance());;//公积金余额
            //缴存基数：等于单位下所有个人的【缴存基数】之和
            PersonalAcc personalAcc1 = mapper.selectBasenumber();
            unityAcc.setBasenumber(personalAcc1.getBasenumber());//缴存基数
            //单位月应缴额：等于单位下所有非销户个人的【单位月应缴额】之和
            PersonalAcc personalAcc2 = mapper.selectUnitmonpaysum();
            unityAcc.setUnitpaysum(personalAcc2.getUnitmonpaysum());//单位月应缴额
            //个人月应缴额：等于单位下所有非销户个人的【个人月应缴额】之和
            PersonalAcc personalAcc3 = mapper.selectPermonpaysum();
            unityAcc.setPerpaysum(personalAcc3.getPermonpaysum());

            UnityAccMapper mapper1 = sqlSession.getMapper(UnityAccMapper.class);
            int insertResult = mapper1.insertSelective(new UnityAcc(
                    unityAcc.getUnitaccnum(),
                    unityAcc.getUnitaccname(),
                    unityAcc.getUnitaddr(),
                    unityAcc.getOrgcode(),
                    unityAcc.getUnitchar(),
                    unityAcc.getUnitkind(),
                    unityAcc.getSalarydate(),
                    unityAcc.getUnitphone(),
                    unityAcc.getUnitlinkman(),
                    unityAcc.getUnitagentpapno(),
                    unityAcc.getAccstate(),
                    unityAcc.getBalance(),
                    unityAcc.getBasenumber(),
                    unityAcc.getUnitprop(),
                    unityAcc.getPerprop(),
                    unityAcc.getUnitpaysum(),
                    unityAcc.getPerpaysum(),
                    unityAcc.getPersnum(),
                    unityAcc.getLastpaydate(),
                    unityAcc.getInstcode(),
                    unityAcc.getOp(),
                    unityAcc.getCreatdate(),
                    unityAcc.getRemark()
            ));
            if (insertResult == 0){
                req.getRequestDispatcher("/homeFailture.jsp").forward(req,resp);
            }else {
                SystemMapper systemMapper = sqlSession.getMapper(SystemMapper.class);
                System seq1 = systemMapper.findSeq("UNITACCNUM");
                int i =seq1.getSeq();
                System system = new System();
                system.setSeq(++i);
                SystemExample updateEx = new SystemExample();
                updateEx.createCriteria().andSeqnameEqualTo("UNITACCNUM");
                systemMapper.updateByExampleSelective(system,updateEx);

                UnityAccMapper unityAccMapper = sqlSession.getMapper(UnityAccMapper.class);
                List<UnityAcc> unityAccs = unityAccMapper.selectByExample(null);
                req.setAttribute("balance",unityAcc.getBalance());
                req.setAttribute("unityList",unityAccs);
                req.getRequestDispatcher("/unityinfo.jsp").forward(req,resp);
            }
        }else if (action.equals("selectUnity")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);

            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            List<UnityAcc> unityAccs = mapper.selectByExample(null);

            req.setAttribute("balance",personalAcc.getBalance());
            req.setAttribute("unityList",unityAccs);
            req.getRequestDispatcher("/unityinfo.jsp").forward(req,resp);
        }else if (action.equals("selectUnityByID")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);
            String unitaccnum = req.getParameter("unitaccnum");

            UnityAcc unityAcc = mapper.selectByPrimaryKey(unitaccnum);
            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            PersonalAccExample personalAccExample = new PersonalAccExample();

            //单位人数：等于单位下所有非销户个人的人数，开户时默认为0
            personalAccExample.createCriteria().andAccnameIsNotNull().andPeraccstateEqualTo("0");
            int personCount = personalAccMapper.countByExample(personalAccExample);
            unityAcc.setPersnum(personCount);               //单位人数
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            unityAcc.setBalance(personalAcc.getBalance());;//公积金余额
            //缴存基数：等于单位下所有个人的【缴存基数】之和
            PersonalAcc personalAcc1 = personalAccMapper.selectBasenumber();
            unityAcc.setBasenumber(personalAcc1.getBasenumber());//缴存基数
            //单位月应缴额：等于单位下所有非销户个人的【单位月应缴额】之和
            PersonalAcc personalAcc2 = personalAccMapper.selectUnitmonpaysum();
            unityAcc.setUnitpaysum(personalAcc2.getUnitmonpaysum());//单位月应缴额
            //个人月应缴额：等于单位下所有非销户个人的【个人月应缴额】之和
            PersonalAcc personalAcc3 = personalAccMapper.selectPermonpaysum();
            unityAcc.setPerpaysum(personalAcc3.getPermonpaysum());

            List<UnityAcc> unityAccList = Collections.singletonList(unityAcc);
            req.setAttribute("unityList",unityAccList);
            req.getRequestDispatcher("/unityinfoDetail.jsp").forward(req,resp);
        }else if (action.equals("updateUnity")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);
            String unitaccnum = req.getParameter("unitaccnum");
            UnityAcc unityAcc = mapper.selectByPrimaryKey(unitaccnum);
            req.setAttribute("unityList",unityAcc);
            req.getRequestDispatcher("/updateUnity.jsp").forward(req,resp);
        }else if (action.equals("updateUnityByIDInfo")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);
            UnityAcc unityAcc = getSingleRequest(req,UnityAcc.class);
            mapper.updateByPrimaryKeySelective(unityAcc);


            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            List<UnityAcc> unityAccs = mapper.selectByExample(null);
            req.setAttribute("balance",personalAcc.getBalance());
            req.setAttribute("unityList",unityAccs);
            req.getRequestDispatcher("/unityinfo.jsp").forward(req,resp);
        }else if (action.equals("SecondUpdateUnity")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);

            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            List<UnityAcc> unityAccs = mapper.selectByExample(null);

            req.setAttribute("balance",personalAcc.getBalance());
            req.setAttribute("unityList",unityAccs);
            req.getRequestDispatcher("/unityinfoUpdate.jsp").forward(req,resp);
        } else if (action.equals("deleteUnity")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);
            String unitaccnum = req.getParameter("unitaccnum");
            mapper.deleteByPrimaryKey(unitaccnum);

            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            List<UnityAcc> unityAccs = mapper.selectByExample(null);
            req.setAttribute("balance",personalAcc.getBalance());
            req.setAttribute("unityList",unityAccs);
            req.getRequestDispatcher("/unityinfo.jsp").forward(req,resp);
        }else if(action.equals("destroyUnity")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);
            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            List<UnityAcc> unityAccs = mapper.selectByExample(null);

            req.setAttribute("balance",personalAcc.getBalance());
            req.setAttribute("unityList",unityAccs);
            req.getRequestDispatcher("/unityinfoDestory.jsp").forward(req,resp);
        }else if(action.equals("destoryUnityByIDInfo")){
            SqlSession sqlSession = SqlSessionUtils.getSqlSession();
            UnityAccMapper mapper = sqlSession.getMapper(UnityAccMapper.class);

            String unitaccnum = req.getParameter("unitaccnum");
            UnityAcc unityAcc = new UnityAcc();
            unityAcc.setUnitaccnum(unitaccnum);
            unityAcc.setAccstate("9");
            unityAcc.setRemark("已销户");
            mapper.updateByPrimaryKeySelective(unityAcc);


            PersonalAccMapper personalAccMapper = sqlSession.getMapper(PersonalAccMapper.class);
            //公积金余额：等于单位下所有个人的【公积金余额】之和
            PersonalAcc personalAcc = personalAccMapper.selectBalance();
            List<UnityAcc> unityAccs = mapper.selectByExample(null);

            req.setAttribute("balance",personalAcc.getBalance());
            req.setAttribute("unityList",unityAccs);
            req.getRequestDispatcher("/unityinfoDestory.jsp").forward(req,resp);
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    public void destroy() {
        super.destroy();
    }

    //反射实体类赋值
    public static <T> T getSingleRequest(HttpServletRequest request, Class<T> obj) {
        //创建实例
        T instance = null;
        try {
            Field[] fields = obj.getDeclaredFields();
            instance = obj.newInstance();
            for (int i = 0; i < fields.length; i++) {
                String name = fields[i].getName();
                if (name.equals("serialVersionUID")) {
                    continue;
                }
                Class<?> type = obj.getDeclaredField(name).getType();

                String replace = name.substring(0, 1).toUpperCase()
                        + name.substring(1);
                Method setMethod = obj.getMethod("set" + replace, type);
                String str = request.getParameter(replace);
                if (str == null || "".equals(str)) {
                    String small = name.substring(0, 1).toLowerCase()
                            + name.substring(1);
                    str = request.getParameter(small);
                }
                if (str != null && !"".equals(str)) {
                    // ---判断读取数据的类型
                    if (type.isAssignableFrom(String.class)) {
                        setMethod.invoke(instance, str);
                    } else if (type.isAssignableFrom(BigDecimal.class)
                            || type.isAssignableFrom(BigDecimal.class)) {
                        setMethod.invoke(instance, str);
                    } else if (type.isAssignableFrom(int.class)
                            || type.isAssignableFrom(Integer.class)) {
                        setMethod.invoke(instance, Integer.parseInt(str));
                    } else if (type.isAssignableFrom(Double.class)
                            || type.isAssignableFrom(double.class)) {
                        setMethod.invoke(instance, Double.parseDouble(str));
                    } else if (type.isAssignableFrom(Boolean.class)
                            || type.isAssignableFrom(boolean.class)) {
                        setMethod.invoke(instance, Boolean.parseBoolean(str));
                    } else if (type.isAssignableFrom(Date.class)) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                        setMethod.invoke(instance, dateFormat.parse(str));
                    } else if (type.isAssignableFrom(Timestamp.class)) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        setMethod.invoke(instance, new Timestamp(dateFormat.parse(str).getTime()));
                    }
                }
            }
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return instance;
    }
}
