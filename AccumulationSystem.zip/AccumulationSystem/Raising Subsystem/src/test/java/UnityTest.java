import com.zhentou.mybatis.mapper.PersonalAccMapper;
import com.zhentou.mybatis.pojo.PersonalAcc;
import com.zhentou.mybatis.pojo.PersonalAccExample;
import com.zhentou.mybatis.pojo.UnityAcc;
import com.zhentou.mybatis.utils.SqlSessionUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class UnityTest {

    @Test
    public void testSelect(){

        SqlSession sqlSession = SqlSessionUtils.getSqlSession();
        PersonalAccMapper mapper = sqlSession.getMapper(PersonalAccMapper.class);
        //公积金余额：等于单位下所有个人的【公积金余额】之和
//        PersonalAcc personalAcc = mapper.selectBalance();
//        System.out.println(personalAcc.getBalance());

//        PersonalAcc personalAcc1 = mapper.selectBasenumber();
//        System.out.println(personalAcc1.getBasenumber());
//
//        PersonalAcc personalAcc2 = mapper.selectUnitmonpaysum();
//        System.out.println(personalAcc2.getUnitmonpaysum());
        PersonalAcc personalAcc2 = mapper.selectPermonpaysum();
        System.out.println(personalAcc2.getPermonpaysum());

    }
}
