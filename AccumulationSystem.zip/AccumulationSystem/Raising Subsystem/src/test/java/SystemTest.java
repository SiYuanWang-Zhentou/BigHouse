import com.zhentou.mybatis.mapper.SystemMapper;
import com.zhentou.mybatis.pojo.System;
import com.zhentou.mybatis.pojo.SystemExample;
import com.zhentou.mybatis.utils.SqlSessionUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

public class SystemTest {

    @Test
    public void testInsert(){
        SqlSession sqlSession = SqlSessionUtils.getSqlSession();
        SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
        int i = mapper.insertSelective(new System("啊发顺丰", 1, 10, "asfasf", "fasfas"));
    }

    @Test
    public void testUpdatet(){
        SqlSession sqlSession = SqlSessionUtils.getSqlSession();
        SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);

        System system = new System();
        system.setSeqname("测试");
        system.setSeq(1);
        system.setMaxseq(22);
        system.setDescScript("测试");

        SystemExample updateExample = new SystemExample();
        updateExample.createCriteria().andSeqnameEqualTo("PERACCNUM");
        mapper.updateByExampleSelective(system,updateExample);
    }
}
