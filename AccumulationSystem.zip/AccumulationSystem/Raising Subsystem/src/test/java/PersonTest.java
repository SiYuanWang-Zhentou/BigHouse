import com.zhentou.mybatis.mapper.PersonalAccMapper;
import com.zhentou.mybatis.mapper.SystemMapper;
import com.zhentou.mybatis.pojo.PersonalAcc;
import com.zhentou.mybatis.pojo.System;
import com.zhentou.mybatis.pojo.SystemExample;
import com.zhentou.mybatis.utils.SqlSessionUtils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.lang.reflect.Field;
import java.util.List;

public class PersonTest {
    @Test
    public static void main(String[] args) throws Exception {
        SqlSession sqlSession = SqlSessionUtils.getSqlSession();
        SystemMapper mapper = sqlSession.getMapper(SystemMapper.class);
        //个人查询取PERACCNUM
        String sname ="PERACCNUM";
        System seq1 = mapper.findSeq(sname);
        String seq = String.format("%012d", seq1.getSeq());
        java.lang.System.out.println(seq);

    }

    @Test
    public static void testupdate(){


    }
}
